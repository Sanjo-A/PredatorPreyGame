/******************************************
*May 9, 2019
*Group 24
*Header file for menu class
*******************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>

class menu
{
  private:

  public:
    menu();
    int getSteps();
    int playAgain();
};

#endif
