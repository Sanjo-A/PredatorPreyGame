/******************************************************
*May 9th, 2019
*Group 24
*Header file for Game class
*******************************************************/

#ifndef GAME_HPP
#define GAME_HPP

#include "doodlebug.hpp"
#include <iostream>

class Game
{
private:

public:
    void game();
    void gameflow(Critter***, int);
};

#endif
